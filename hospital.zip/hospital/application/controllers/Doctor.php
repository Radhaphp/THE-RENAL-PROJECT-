<?php
class Doctor extends CI_Controller 
{

        public function index()
        {
                $this->load->view('doctor');
        }


         public function create()
         {
          $this->form_validation->set_rules('username','User Name','required|alpha');
          $this->form_validation->set_rules('password','Password','required|max_length[12]');
          $this->form_validation->set_error_delimiters('<div class="text-danger">', '</div>');
          if($this->form_validation->run())
          {
           $username=$this->input->post('username');
           $password=$this->input->post('password');
           $this->load->model('Dclogin_model');
           $login_id=$this->Dclogin_model->isvalidate($username,$password);
           if($login_id)
           {
               $this->session->set_userdata('id',$login_id);
               return redirect('doctorview');
          }
           else
           {
              $this->session->set_flashdata('Login_failed','Invalid Username/Password');
              return redirect('admin');
           }


          }
          else
          {
           $this->load->view('doctor');
          }

 }
}
?>