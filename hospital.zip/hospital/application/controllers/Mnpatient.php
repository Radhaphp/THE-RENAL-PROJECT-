<?php  
class Mnpatient extends CI_Controller 
{
        public function __construct()
        {
        /*call CodeIgniter's default Constructor*/
        parent::__construct();
        
        /*load database libray manually*/
        $this->load->database();
        
        }
        public function index(){
                $this->load->model("ptmodel");
                $fetch_data = $this->ptmodel->fetch_data(); 
                $this->load->view("mnpatient",array('fetch_data'=>$fetch_data));
                
        }       
        public function update()
        {
                $userid=$this->uri->segment(3);
                
                $this->load->model("ptmodel");
                $data["user_data"]=$this->ptmodel->fetch_single_data($userid);
                $this->load->view("up_patient",$data);
                
        }
        
        public function update_row()
        {
                $data=$this->input->post();
                unset($data['update_row']);
                $this->load->model("ptmodel");
                if($this->ptmodel->update($data))
                {
                        $this->load->library('session');
                        $this->session->set_flashdata('result','Record Updated.');
                        return redirect('mnpatient');
                }
                else
                {
                        echo "failed";
                }
        }
        public function delete_data()
        {
                $id=$this->uri->segment(3);
                $this->load->model("ptmodel");  
                $this->ptmodel->delete_data($id);  
                return redirect("mnpatient");  
        }
        public function deleted()
        
        {
                 $this->index();
        }
}
?>