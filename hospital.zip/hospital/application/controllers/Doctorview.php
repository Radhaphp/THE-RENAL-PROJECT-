<?php
class Doctorview extends CI_Controller {

        public function index()
        {
                $this->load->view('doctorview');
        }       
}
?>