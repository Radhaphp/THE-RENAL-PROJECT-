<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Addpatient extends CI_Controller 
{

        
        function __construct()
        {
                parent::__construct();
                $this->load->helper('url');
                $this->load->model('Ptmodel');
                $this->load->library('session');
                $this->load->library('form_validation');                
        }
        
        public function index()
        {
                $this->load->view('addpatient');
                
        }
        
        public function validation()
        {
                $data = $this->input->post();

                $this->form_validation->set_rules('firstname','Firstname','required|trim');
                $this->form_validation->set_rules('lastname','Lastname','required|trim');
                $this->form_validation->set_rules('phone','Phone No','required|trim');
                $this->form_validation->set_rules('password','Password','required|trim');
                $this->form_validation->set_rules('age','Age','required|trim');
                $this->form_validation->set_rules('address','Address','required|trim');
        
                if ($this->form_validation->run() == FALSE) 
                {
                        $this->load->view('addpatient');
                        } else {
                        
                        $this->Ptmodel->form_insert($data);
                        $sucess['message'] = 'Data Inserted Successfully';
                        return redirect("mnpatient",$sucess);  
                }
        }       
}
