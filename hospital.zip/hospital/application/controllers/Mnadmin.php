<?php  
class Mnadmin extends CI_Controller 
{
        public function __construct()
        {
        /*call CodeIgniter's default Constructor*/
        parent::__construct();
        
        /*load database libray manually*/
        $this->load->database();
        
        }
        public function index(){
                $this->load->model("Addmodel");
                $fetch_data = $this->Addmodel->fetch_data(); 
                $this->load->view("mnadmin",array('fetch_data'=>$fetch_data));
                
        }       
        public function update()
        {
                $userid=$this->uri->segment(3);
                
                $this->load->model("Addmodel");
                $data["user_data"]=$this->Addmodel->fetch_single_data($userid);
                $this->load->view("up_admin",$data);
                
        }
        
        public function update_row()
        {
                $data=$this->input->post();
                unset($data['update_row']);
                $this->load->model("Addmodel");
                if($this->Addmodel->update($data))
                {
                        $this->load->library('session');
                        $this->session->set_flashdata('result','Record Updated.');
                        return redirect('mnadmin');
                }
                else
                {
                        echo "failed";
                }
        }
        public function delete_data()
        {
                $id=$this->uri->segment(3);
                $this->load->model("Addmodel");  
                $this->Addmodel->delete_data($id);  
                return redirect("mnadmin");  
        }
        public function deleted()
        
        {
                 $this->index();
        }
}
?>