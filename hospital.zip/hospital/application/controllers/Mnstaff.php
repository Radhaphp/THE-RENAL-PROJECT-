<?php  
class Mnstaff extends CI_Controller 
{
        public function __construct()
        {
        /*call CodeIgniter's default Constructor*/
        parent::__construct();
        
        /*load database libray manually*/
        $this->load->database();
        
        }
        public function index(){
                $this->load->model("Sfmodel");
                $fetch_data = $this->Sfmodel->fetch_data(); 
                $this->load->view("mnstaff",array('fetch_data'=>$fetch_data));
                
        }       
        public function update()
        {
                $userid=$this->uri->segment(3);
                
                $this->load->model("Sfmodel");
                $data["user_data"]=$this->Sfmodel->fetch_single_data($userid);
                $this->load->view("up_staff",$data);
                
        }
        
        public function update_row()
        {
                $data=$this->input->post();
                unset($data['update_row']);
                $this->load->model("Sfmodel");
                if($this->Sfmodel->update($data))
                {
                        $this->load->library('session');
                        $this->session->set_flashdata('result','Record Updated.');
                        return redirect('mnstaff');
                }
                else
                {
                        echo "failed";
                }
        }
        public function delete_data()
        {
                $id=$this->uri->segment(3);
                $this->load->model("Sfmodel");  
                $this->Sfmodel->delete_data($id);  
                return redirect("mnstaff");  
        }
        public function deleted()
        
        {
                 $this->index();
        }
}
?>