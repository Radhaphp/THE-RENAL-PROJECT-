<?php  
class Mndoctor extends CI_Controller 
{
        public function __construct()
        {
        /*call CodeIgniter's default Constructor*/
        parent::__construct();
        
        /*load database libray manually*/
        $this->load->database();
        
        }
        public function index(){
                $this->load->model("Dcmodel");
                $fetch_data = $this->Dcmodel->fetch_data(); 
                $this->load->view("mndoctor",array('fetch_data'=>$fetch_data));
                
        }       
        public function update()
        {
                $userid=$this->uri->segment(3);
                
                $this->load->model("Dcmodel");
                $data["user_data"]=$this->Dcmodel->fetch_single_data($userid);
                $this->load->view("up_doctor",$data);
                
        }
        
        public function update_row()
        {
                $data=$this->input->post();
                unset($data['update_row']);
                $this->load->model("Dcmodel");
                if($this->Dcmodel->update($data))
                {
                        $this->load->library('session');
                        $this->session->set_flashdata('result','Record Updated.');
                        return redirect('mndoctor');
                }
                else
                {
                        echo "failed";
                }
        }
        public function delete_data()
        {
                $id=$this->uri->segment(3);
                $this->load->model("Dcmodel");  
                $this->Dcmodel->delete_data($id);  
                return redirect("mndoctor");  
        }
        public function deleted()
        
        {
                 $this->index();
        }
}
?>