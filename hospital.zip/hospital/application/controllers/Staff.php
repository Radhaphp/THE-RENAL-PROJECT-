<?php
class Staff extends CI_Controller 
{

        public function index()
        {
                $this->load->view('staff');
        }


         public function create()
         {
          $this->form_validation->set_rules('username','User Name','required|alpha');
          $this->form_validation->set_rules('password','Password','required|max_length[12]');
          $this->form_validation->set_error_delimiters('<div class="text-danger">', '</div>');
          if($this->form_validation->run())
          {
           $username=$this->input->post('username');
           $password=$this->input->post('password');
           $this->load->model('Sflogin_model');
           $login_id=$this->Sflogin_model->isvalidate($username,$password);
           if($login_id)
           {
               $this->session->set_userdata('id',$login_id);
               return redirect('staffview');
          }
           else
           {
              $this->session->set_flashdata('Login_failed','Invalid Username/Password');
              return redirect('staff');
           }


          }
          else
          {
           $this->load->view('staff');
          }

 }
}
?>