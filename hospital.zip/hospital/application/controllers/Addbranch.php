<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Addbranch extends CI_Controller 
{

        
        function __construct()
        {
                parent::__construct();
                $this->load->helper('url');
                $this->load->model('Brmodel');
                $this->load->library('session');
                $this->load->library('form_validation');                
        }
        
        public function index()
        {
                $this->load->view('addbranch');
                
        }
        
        public function check()
        {
                $data = $this->input->post();

                $this->form_validation->set_rules('branch','Branch Name','required|trim');
                $this->form_validation->set_rules('amount','Amount','required|trim'); 
        
                if ($this->form_validation->run() == FALSE) 
                {
                        $this->load->view('addbranch');
                        } else {
                        
                        $this->Brmodel->form_insert($data);
                        $sucess['message'] = 'Data Inserted Successfully';
                        return redirect("mnbranch",$sucess);  
                }
        }       
}
