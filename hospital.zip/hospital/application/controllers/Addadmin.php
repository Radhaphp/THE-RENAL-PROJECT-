<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Addadmin extends CI_Controller 
{

        
        function __construct()
        {
                parent::__construct();
                $this->load->helper('url');
                $this->load->model('Addmodel');
                $this->load->library('session');
                $this->load->library('form_validation');                
        }
        
        public function index()
        {
                $this->load->view('addadmin');
                
        }
        
        public function check()
        {
                $data = $this->input->post();

                $this->form_validation->set_rules('firstname','Firstname','required|trim');
                $this->form_validation->set_rules('lastname','Lastname','required|trim');
                $this->form_validation->set_rules('username','Username','required|trim');
                $this->form_validation->set_rules('password','Password','required|trim');
                $this->form_validation->set_rules('email','Email','required|trim');
                $this->form_validation->set_rules('phone','Phone No','required|trim');
                $this->form_validation->set_rules('address','Address','required|trim');
                
        
                if ($this->form_validation->run() == FALSE) 
                {
                        $this->load->view('addadmin');
                        } else {
                        
                        $this->Addmodel->form_insert($data);
                        $sucess['message'] = 'Data Inserted Successfully';
                        return redirect("mnadmin",$sucess);  
                }
        }       
}
