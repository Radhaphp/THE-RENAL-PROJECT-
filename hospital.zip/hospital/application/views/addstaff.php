<?php include('header.php'); ?>

<div class="pcoded-content">
                        <div class="pcoded-inner-content">

                            <!-- Main-body start -->
                            <div class="main-body">
                                <div class="page-wrapper">
                                    <!-- Page-header start -->
                                    <div class="page-header card">
                                        <div class="row align-items-end">
                                            <div class="col-lg-8">
                                                <div class="page-header-title">
                                                    <i class="icofont icofont-file-code bg-c-blue"></i>
                                                    <div class="d-inline">
                                                        <h4>Add Staff</h4>
                                                        <span>Fill This Form</span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- Page-header end -->

                                    <!-- Page body start -->
                                    <div class="page-body">
                                        <div class="row">
                                            <div class="col-sm-12">
                                                <!-- Basic Form Inputs card start -->
                                                <div class="card">
                                                    <div class="card-header">
                                                        <h5>Staff Form</h5>
                                                        <div class="card-header-right"><i
                                                        class="icofont icofont-spinner-alt-5"></i></div>
                                                            <div class="card-header-right">
                                                                <i class="icofont icofont-spinner-alt-5"></i>
                                                            </div>
                                                        </div>
                                            <div class="card-block">
                                               <?php if (isset($message)) { echo $message; }?>         
                                               <form action="<?php echo base_url('addstaff/check'); ?>" method="post">  
                                                                <div class="form-group row">
                                                                    <label class="col-sm-2 col-form-label">Firstname</label>
                                                                    <div class="col-sm-10">
                                                                        <input type="text" class="form-control"
                                                                        placeholder="Enter Firstname"
                                                                        name="firstname">
                                                                    </div>
                                                                </div>
                                                                 <div class="form-group row">
                                                                    <label class="col-sm-2 col-form-label">Lastname</label>
                                                                    <div class="col-sm-10">
                                                                        <input type="text" class="form-control"
                                                                        placeholder="Enter Lastname"
                                                                        name="lastname">
                                                                    </div>
                                                                </div>               
                                                                <div class="form-group row">
                                                                    <label class="col-sm-2 col-form-label">Username</label>
                                                                    <div class="col-sm-10">
                                                                        <input type="text" class="form-control"
                                                                        placeholder="Enter Username" name="username">
                                                                    </div>
                                                                </div>
                                                                <?=form_error('User Name')?>
                                                                <div class="form-group row">
                                                                    <label class="col-sm-2 col-form-label">Password</label>
                                                                    <div class="col-sm-10">
                                                                        <input type="password" class="form-control"
                                                                        placeholder="Enter Password"
                                                                        name="password">
                                                                    </div>
                                                                </div>
                                                                <div class="form-group row">
                                                                    <label class="col-sm-2 col-form-label">Email</label>
                                                                    <div class="col-sm-10">
                                                                        <input type="email" class="form-control"
                                                                        placeholder="Enter Email" name="email">
                                                                    </div>
                                                                </div>
                                                               <div class="form-group row">
                                                                    <label class="col-sm-2 col-form-label">Phone No:</label>
                                                                    <div class="col-sm-10">
                                                                        <input type="text" class="form-control"
                                                                        placeholder="Enter Phone Number" name="phone">
                                                                    </div>
                                                                </div>
                                                                <div class="form-group row">
                                                                    <label class="col-sm-2 col-form-label">Address</label>
                                                                    <div class="col-sm-10">
                                                                        <input type="text" class="form-control"
                                                                        placeholder="Enter Address" name="address">
                                                                    </div>
                                                                </div>
                                                                <input type="submit" class="btn btn-primary waves-effect waves-light" value="Submit">
                                                            </form>
                                                       </div>
                                                </div>
                                         <!-- Page body end -->
                                        </div>
                                </div>
                           <!-- Main-body end -->
                        <div id="styleSelector">
                     </div>
                  </div>
               </div>                                           
             </div>
           </div>
        </div>
    </div>

    <?php include('footer.php'); ?>