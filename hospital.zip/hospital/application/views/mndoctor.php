<?php include('header.php'); ?>                   
                    <div class="pcoded-content">
                        <div class="pcoded-inner-content">

                            <!-- Main-body start -->
                            <div class="main-body">
                                <div class="page-wrapper">
                                    <!-- Page-header start -->
                                    <div class="page-header card">
                                        <div class="row align-items-end">
                                            <div class="col-lg-8">
                                                <div class="page-header-title">
                                                    <i class="icofont icofont-file-code bg-c-blue"></i>
                                                    <div class="d-inline">
                                                        <h4>Manage doctor</h4>
                                                        <span>edit/delete admin</span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- Page-header end -->

                                    <!-- Page body start -->
                                   <div class="page-body">
                                    <!-- Basic table card start -->
                                    <div class="card">
                                        <div class="card-header">
                                            <h5>Admin table</h5>
                                        </div>
                                        <div class="card-block table-border-style">
                                            <div class="table-responsive">
                                                <table class="table">
                                                    <thead>
                                                        <tr>
                                                            <th>Id</th>
                                                            <th>Firstname</th>
                                                            <th>Lastname</th>
                                                            <th>Username</th>
                                                            <th>Password</th>
                                                            <th>Email</th>
                                                            <th>Phone No</th>
                                                            <th>Address</th>
                                                            <th style="width:10%;">Action</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <tr>
                                                             <?php  
                                                                $i=1;
                                                                foreach($fetch_data as $row): 
                                                                ?>  
                                                            <td><?php echo $i++; ?></td>
                                                            <td><?php echo $row['firstname']; ?></td>
                                                            <td><?php echo $row['lastname']; ?></td>
                                                            <td><?php echo $row['username']; ?></td>
                                                            <td><?php echo $row['password']; ?></td>
                                                            <td><?php echo $row['email']; ?></td>
                                                            <td><?php echo $row['phone']; ?></td>
                                                            <td><?php echo $row['address']; ?></td>
                                                            <td><a href="<?php echo base_url(); ?>Mndoctor/update/<?php echo $row['id']; ?>" class="btn btn-primary btn-sm"><i class="ti-pencil-alt"></a></td>
                                                            <td><a href="<?php echo base_url();?>Mndoctor/delete_data/<?php echo $row['id']; ?>" i class="delete_data btn btn-danger btn-sm" id="<?php echo $row['id']; ?>"><i class="ti-trash"></i></a></td> 
                                                        </tr>
                                                    </tbody>
                                                    <?php       
                                                        endforeach; 
                                                        ?> 
                                                </table>
                                            </div>
                                        </div>
                                    </div>

                           <!-- Main-body end -->
                        <div id="styleSelector">
                     </div>
                  </div>
               </div>                                           
             </div>
           </div>
        </div>
    </div>
 <?php include('footer.php'); ?>

      