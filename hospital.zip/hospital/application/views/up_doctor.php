<?php include('header.php'); ?>   
                    <div class="pcoded-content">
                        <div class="pcoded-inner-content">

                            <!-- Main-body start -->
                            <div class="main-body">
                                <div class="page-wrapper">
                                    <!-- Page-header start -->
                                    <div class="page-header card">
                                        <div class="row align-items-end">
                                            <div class="col-lg-8">
                                                <div class="page-header-title">
                                                    <i class="icofont icofont-file-code bg-c-blue"></i>
                                                    <div class="d-inline">
                                                        <h4>Add Doctor</h4>
                                                        <span>Fill This Form</span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- Page-header end -->

                                    <!-- Page body start -->
                                    <div class="page-body">
                                        <div class="row">
                                            <div class="col-sm-12">
                                                <!-- Basic Form Inputs card start -->
                                                <div class="card">
                                                    <div class="card-header">
                                                        <h5>Doctor Form</h5>
                                                        <div class="card-header-right"><i
                                                        class="icofont icofont-spinner-alt-5"></i></div>
                                                            <div class="card-header-right">
                                                                <i class="icofont icofont-spinner-alt-5"></i>
                                                            </div>
                                                        </div>
                                            <div class="card-block">
                                               <form action="<?php echo base_url('Mndoctor/update_row'); ?>" method="post">
                                                          <?php  
                                                            foreach($user_data as $row)  
                                                            {  
                                                             ?>
                                                                <div class="form-group row">
                                                                    <label class="col-sm-2 col-form-label">Firstname</label>
                                                                    <div class="col-sm-10">
                                                                        <input type="text" class="form-control"
                                                                        placeholder="Enter Firstname"
                                                                        name="firstname" value="<?php echo $row['firstname'];?>" />
                                                                    </div>
                                                                </div>
                                                                 <div class="form-group row">
                                                                    <label class="col-sm-2 col-form-label">Lastname</label>
                                                                    <div class="col-sm-10">
                                                                        <input type="text" class="form-control"
                                                                        placeholder="Enter Firstname"
                                                                        name="lastname" value="<?php echo $row['lastname'];?>" />
                                                                    </div>
                                                                </div>               
                                                                <div class="form-group row">
                                                                    <label class="col-sm-2 col-form-label">Username</label>
                                                                    <div class="col-sm-10">
                                                                        <input type="text" class="form-control"
                                                                        placeholder="Enter Username" name="username" value="<?php echo $row['username'];?>" />
                                                                    </div>
                                                                </div>
                                                                <?=form_error('User Name')?>
                                                                <div class="form-group row">
                                                                    <label class="col-sm-2 col-form-label">Password</label>
                                                                    <div class="col-sm-10">
                                                                        <input type="password" class="form-control"
                                                                        placeholder="Enter Password"
                                                                        name="password" value="<?php echo $row['password'];?>" />
                                                                    </div>
                                                                </div>
                                                                <div class="form-group row">
                                                                    <label class="col-sm-2 col-form-label">Email</label>
                                                                    <div class="col-sm-10">
                                                                        <input type="email" class="form-control"
                                                                        placeholder="Enter Email" name="email" value="<?php echo $row['email'];?>" />
                                                                    </div>
                                                                </div>
                                                               <div class="form-group row">
                                                                    <label class="col-sm-2 col-form-label">Phone No:</label>
                                                                    <div class="col-sm-10">
                                                                        <input type="text" class="form-control"
                                                                        placeholder="Enter Phone Number" name="phone" value="<?php echo $row['phone'];?>" />
                                                                    </div>
                                                                </div>
                                                                <div class="form-group row">
                                                                    <label class="col-sm-2 col-form-label">Address</label>
                                                                    <div class="col-sm-10">
                                                                        <input type="text" class="form-control"
                                                                        placeholder="Enter Address" name="address" value="<?php echo $row['address'];?>" />
                                                                    </div>
                                                                </div>
                                                                 <input type="hidden" name="id" value="<?php echo $row['id']; ?>" /> 
                                                                <input type="submit" class="btn btn-primary waves-effect waves-light" value="Update">
                                                            </form>
                                                             <?php }?>
                                                       </div>
                                                </div>
                                         <!-- Page body end -->
                                        </div>
                                </div>
                           <!-- Main-body end -->
                        <div id="styleSelector">
                     </div>
                  </div>
               </div>                                           
             </div>
           </div>
        </div>
    </div>
<?php include('footer.php'); ?>