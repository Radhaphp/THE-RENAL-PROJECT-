<?php
class Dcmodel extends CI_Model 
{
   
	public function fetch_data()
	{
		$query = $this 
				-> db
				-> select('*')
    			-> get('doctor')
				-> result_array(); 
		return $query;
	
	}
	public function form_insert($data)
	{
		$this->db->insert('doctor', $data);
		return true;
	}
	
	public function delete_data($id)
	{  
        $this->db->where("id", $id);  
        $this->db->delete("doctor");  
    }  
	
	public function fetch_single_data($userid)
	{ 
	
		$query=$this->db->select('*')
						->where('id',$userid)
						->get('doctor');
		return $query->result_array();

	}
	
	public function update($upd)
	{
		$id=$upd['id'];
		unset($upd['id']);
		return $this->db->where('id',$id)->update("doctor",$upd);
		
	}
}
?> 
