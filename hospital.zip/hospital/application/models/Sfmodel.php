<?php
class Sfmodel extends CI_Model 
{
   
	public function fetch_data()
	{
		$query = $this 
				-> db
				-> select('*')
    			-> get('staff')
				-> result_array(); 
		return $query;
	
	}
	public function form_insert($data)
	{
		$this->db->insert('staff', $data);
		return true;
	}
	
	public function delete_data($id)
	{  
        $this->db->where("id", $id);  
        $this->db->delete("staff");  
    }  
	
	public function fetch_single_data($userid)
	{ 
	
		$query=$this->db->select('*')
						->where('id',$userid)
						->get('staff');
		return $query->result_array();

	}
	
	public function update($upd)
	{
		$id=$upd['id'];
		unset($upd['id']);
		return $this->db->where('id',$id)->update("staff",$upd);
		
	}
}
?> 
