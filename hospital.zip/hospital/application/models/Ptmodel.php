<?php
class Ptmodel extends CI_Model 
{
   
	public function fetch_data()
	{
		$query = $this 
				-> db
				-> select('*')
    			-> get('patient')
				-> result_array(); 
		return $query;
	
	}
	public function form_insert($data)
	{
		$this->db->insert('patient', $data);
		return true;
	}
	
	public function delete_data($id)
	{  
        $this->db->where("id", $id);  
        $this->db->delete("patient");  
    }  
	
	public function fetch_single_data($userid)
	{ 
	
		$query=$this->db->select('*')
						->where('id',$userid)
						->get('patient');
		return $query->result_array();

	}
	
	public function update($upd)
	{
		$id=$upd['id'];
		unset($upd['id']);
		return $this->db->where('id',$id)->update("patient",$upd);
		
	}
}
?> 
