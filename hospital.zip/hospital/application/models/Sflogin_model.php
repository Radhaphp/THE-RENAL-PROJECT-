 <?php
class Sflogin_model extends CI_Model
{
  public function isvalidate($username,$password)
  {
   $q=$this->db->where(['username'=>$username,'password'=>$password])
               ->get('staff');
              
   //select * from users where username=$username and password=$password
        
           if($q->num_rows())     
           {
           return $q->row()->id;
           }   
           else
           {
           	return false;
           }
   }
} 
?>